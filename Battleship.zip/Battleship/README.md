# Battleship

By Bryce Gramling and Cullen Huffines

Battleship.java contains the main function for the program. Running java Battleship will start the game. 
The functions used by the program are in the setup.java file. 